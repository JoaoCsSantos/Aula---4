﻿//Declare as variáveis nome, idade e nota atribuindo os valores “Paulo”, 17 e 7.5 e exiba a saída no formato : Aluno tem anos e nota usando a concatenação e a interpolação de strings.
//Para o exercício anterior exiba o nome a idade e a nota em linhas separadas usando as sequências de escapes.
//  string nome = "Paulo";
//         int idade = 17;
//         double nota = 7.5;

//         string saidaConcatenacao = "Aluno " + nome + " tem " + idade + " anos e nota " + nota;

//         string saidaInterpolacao = $"Aluno {nome} tem {idade} anos e nota {nota}";

//         Console.WriteLine(saidaConcatenacao + "\n");

       
//         Console.WriteLine(saidaInterpolacao);
//==================================================================================================
// Para qual tipo de dados você pode converter um float implicitamente ?
// ( ) int
// (X) double //
// ( ) long
// ( ) decimal 
//==================================================================================================
// Em qual conversão numérica você precisaria realizar o casting (convesão forçada) ?
// ( ) int para long
// ( ) double para long
// ( ) double para float
// (X) decimal para float //
// ( ) long para int
// ( ) double para decimal
//==================================================================================================
// Escreva um programa que recebe 3 letras via teclado e as exiba na ordem reversa usando
// a concatenação e também a interpolação de strings
// Console.WriteLine("Digite três letras:");

//         string letra1 = Console.ReadLine();
//         string letra2 = Console.ReadLine();
//         string letra3 = Console.ReadLine();

//         string reversoConcatenacao = "Ordem reversa (concatenação): " + letra3 + letra2 + letra1;

//         string reversoInterpolacao = $"Ordem reversa (interpolação): {letra3}{letra2}{letra1}";

//         Console.WriteLine(reversoConcatenacao);
//         Console.WriteLine(reversoInterpolacao);
//==================================================================================================
// Marque verdadeiro(V) ou falso(F) para os códigos abaixo:
// (V) long resultado = 1.32;
// (V) var nome = “Maria”;
// (V) string resultado = 100.ToString();
// (V) A sequência de escape \n inclui uma nova linha
// (F) float f = 5.45;
// (V) decimal valor = (decimal) 10.99f;
// (F) var status = null;
// (V) object o = 12.45m;
// (V) string titulo = true.ToString();
// (F) A sequencia \t inclui uma tabulação vertical
//==================================================================================================
// Escreva um programa para receber dois valores via teclado do tipo double e a seguir
// realize as operações de soma, subtração, multiplicação, exponenciação, divisão e módulo
// exibindo o resultado:

// Console.WriteLine("Digite o primeiro valor:");
//         double valor1 = Convert.ToDouble(Console.ReadLine());

//         Console.WriteLine("Digite o segundo valor:");
//         double valor2 = Convert.ToDouble(Console.ReadLine());

//         double soma = valor1 + valor2;
//         double subtracao = valor1 - valor2;
//         double multiplicacao = valor1 * valor2;
//         double exponenciacao = Math.Pow(valor1, valor2);
//         double divisao = valor1 / valor2;
//         double modulo = valor1 % valor2;

//         Console.WriteLine($"Soma: {soma}");
//         Console.WriteLine($"Subtração: {subtracao}");
//         Console.WriteLine($"Multiplicação: {multiplicacao}");
//         Console.WriteLine($"Exponenciação: {exponenciacao}");
//         Console.WriteLine($"Divisão: {divisao}");
//         Console.WriteLine($"Módulo: {modulo}");

//==================================================================================================

// Escreva um programa que receba um nome e uma senha via teclado. Nome é uma string e
// Senha é um inteiro. Se o nome for igual a ‘admin’ ou ‘maria’ e a senha for igual a ‘123’
// então exiba a mensagem ‘Login feito com sucesso’ caso contrário exiba a mensagem ‘Login
// inválido’: (use o operador condicional ternário)

// Console.WriteLine("Digite o nome:");
//         string nome = Console.ReadLine();

//         Console.WriteLine("Digite a senha:");
//         int senha = Convert.ToInt32(Console.ReadLine());

//         string mensagem = (nome == "admin" || nome == "maria") && senha == 123 ? "Login feito com sucesso" : "Login inválido";

//         Console.WriteLine(mensagem);

//==================================================================================================

// Escreva um programa que recebe via teclado dois números inteiros x e y e imprima no
// console se x é par ou não e se y é par ou não. Use o operador condicional ternário (? :)

// Console.WriteLine("Digite o primeiro número inteiro:");
//         int x = Convert.ToInt32(Console.ReadLine());

//         Console.WriteLine("Digite o segundo número inteiro:");
//         int y = Convert.ToInt32(Console.ReadLine());

//         string parOuNaoX = x % 2 == 0 ? "par" : "ímpar";

//         string parOuNaoY = y % 2 == 0 ? "par" : "ímpar";

//         Console.WriteLine($"O número {x} é {parOuNaoX}");
//         Console.WriteLine($"O número {y} é {parOuNaoY}");

//==================================================================================================